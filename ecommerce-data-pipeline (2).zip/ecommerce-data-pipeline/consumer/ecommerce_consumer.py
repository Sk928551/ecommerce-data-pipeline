from confluent_kafka import Consumer
import json
import snowflake.connector

conf = {
    'bootstrap.servers': 'localhost:9092',
    'group.id': 'ecom-group',
    'auto.offset.reset': 'earliest'
}
consumer = Consumer(conf)
consumer.subscribe(['ecommerce_orders'])

conn = snowflake.connector.connect(
    user='YOUR_USERNAME',
    password='YOUR_PASSWORD',
    account='YOUR_ACCOUNT_ID',
    warehouse='YOUR_WAREHOUSE',
    database='YOUR_DATABASE',
    schema='YOUR_SCHEMA'
)
cursor = conn.cursor()

try:
    while True:
        msg = consumer.poll(1.0)
        if msg is None:
            continue
        if msg.error():
            print("Error:", msg.error())
            continue

        order = json.loads(msg.value().decode('utf-8'))
        print("Inserting:", order)

        cursor.execute("""
            INSERT INTO orders (order_id, customer_name, product, amount, order_date)
            VALUES (%s, %s, %s, %s, %s)
        """, (
            order['order_id'],
            order['customer_name'],
            order['product'],
            order['amount'],
            order['order_date']
        ))

except KeyboardInterrupt:
    pass

finally:
    consumer.close()
    cursor.close()
    conn.close()
