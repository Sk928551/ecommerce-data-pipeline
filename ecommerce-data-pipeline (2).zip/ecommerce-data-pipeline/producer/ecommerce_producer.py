from kafka import KafkaProducer
import json
from faker import Faker
import random
from datetime import datetime, timedelta

# Initialize Kafka Producer
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Fake data generator
fake = Faker()

def generate_order(order_id):
    return {
        "order_id": order_id,
        "customer_name": fake.name(),
        "product": random.choice(["Laptop", "Smartphone", "Tablet", "Monitor", "Headphones", "Keyboard", "Mouse"]),
        "amount": round(random.uniform(100, 2000), 2),
        "order_date": (datetime.today() - timedelta(days=random.randint(0, 30))).strftime('%Y-%m-%d')
    }

# Generate and send 100 fake orders
for i in range(101, 201):  # Order IDs from 101 to 200
    order = generate_order(i)
    print(f"Sending: {order}")
    producer.send('ecommerce_orders', value=order)

producer.flush()