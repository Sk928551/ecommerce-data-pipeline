CREATE DATABASE ecommerce_db;
USE DATABASE ecommerce_db;

CREATE SCHEMA ecommerce_schema;
USE SCHEMA ecommerce_schema;

CREATE TABLE orders (
  order_id INT,
  customer_name STRING,
  product STRING,
  amount FLOAT,
  order_date DATE
);
